import Members from "../components/load/members";

const Load = () => {

  return (
    <main className="main container">
      <Members />
    </main>
  );
};

export default Load;
