import AddForm from "../components/add/addForm";

const Add = () => {
  return (
    <main className="main container">
      <AddForm />
    </main>
  );
};

export default Add;
